package com.Capstone.BankingApp.bankcontroller;

import org.springframework.stereotype.Controller;

import com.Capstone.BankingApp.entity.User;
import com.Capstone.BankingApp.service.AccountInfoService;

@Controller
public class AccountInfoController {
	
	AccountInfoService accountInfoService;

	public AccountInfoController(AccountInfoService accountInfoService) {
		super();
		this.accountInfoService = accountInfoService;
	}
	
	public void control() {
		accountInfoService.showAccountInfo(1);
	}
	
	public void control2() {
		User user = new User();
		accountInfoService.editSecurityQuestion(1, user);
	}
	
	public void control3() {
		User user = new User();
		accountInfoService.editSecurityAnswer(1, user);
	}

}
