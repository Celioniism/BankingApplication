package com.Capstone.BankingApp.bankcontroller;

import org.springframework.stereotype.Controller;

import com.Capstone.BankingApp.entity.GeneralStaff;
import com.Capstone.BankingApp.service.GeneralStaffService;

@Controller
public class GeneralStaffController {
	
	GeneralStaffService generalStaffService;

	public GeneralStaffController(GeneralStaffService generalStaffService) {
		super();
		this.generalStaffService = generalStaffService;
	}
	
	public void control() {
		generalStaffService.showStaffInfo(1);
	}
	
	public void control2() {
		GeneralStaff generalStaff = new GeneralStaff();
		generalStaffService.editStaffUsername(1, generalStaff);
	}
	
	public void control3() {
		GeneralStaff generalStaff = new GeneralStaff();
		generalStaffService.editStaffPassword(1, generalStaff);
	}
	
	public void control4() {
		GeneralStaff generalStaff = new GeneralStaff();
		generalStaffService.editStaffFullName(1, generalStaff);
	}

}
