package com.Capstone.BankingApp.bankcontroller;

import org.springframework.stereotype.Controller;
import com.Capstone.BankingApp.service.UserInfoFactoryService;

@Controller
public class UserInfoFactoryController {
	
	UserInfoFactoryService userInfoFactoryService;

	public UserInfoFactoryController(UserInfoFactoryService userInfoFactoryService) {
		super();
		this.userInfoFactoryService = userInfoFactoryService;
	}
	
	public void control() {
		userInfoFactoryService.showUserInfoFactoryDetails(1);
	}
}
