package com.Capstone.BankingApp.bankcontroller;

import org.springframework.stereotype.Controller;
import com.Capstone.BankingApp.service.CardsService;

@Controller
public class CardsController {
	
	CardsService cardsService;

	public CardsController(CardsService cardsService) {
		super();
		this.cardsService = cardsService;
	}
	
	public void control() {
		cardsService.showCardDetails(1);
	}


}
