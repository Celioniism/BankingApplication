package com.Capstone.BankingApp.bankcontroller;

import org.springframework.stereotype.Controller;

import com.Capstone.BankingApp.entity.Administrator;
import com.Capstone.BankingApp.service.AdminService;

@Controller
public class AdminController {
	
	AdminService adminService;

	public AdminController(AdminService adminService) {
		super();
		this.adminService = adminService;
	}
	
	public void control() {
		adminService.showAdminInfo(1);
	}
	
	public void control2() {
		Administrator admin = new Administrator();
		adminService.editAdminUsername(1, admin);
	}
	
	public void control3() {
		Administrator admin = new Administrator();
		adminService.editAdminFullName(1, admin);
	}
	
	public void control4() {
		Administrator admin = new Administrator();
		adminService.editAdminPassword(1, admin);
	}

}
