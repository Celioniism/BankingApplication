package com.Capstone.BankingApp.bankcontroller;

import org.springframework.stereotype.Controller;

import com.Capstone.BankingApp.entity.User;
import com.Capstone.BankingApp.service.UserService;

@Controller
public class UserController {
	
	UserService userService;

	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}
	
	public void control() {
		userService.showRegularUserInfo(1);
	}
	
	public void control2() {
		User user = new User();
		userService.editUsername(1, user);
	}
	
	public void control3() {
		User user = new User();
		userService.editUserPassword(1, user);
	}
	
	public void control4() {
		User user = new User();
		userService.editFullName(1, user);
	}

}
